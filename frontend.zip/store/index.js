export const state = () => ({
	courses: [],
	videos: [],
	tags: [],
	users: [],
	instructor: [],
})

export const mutations = {
	SET_VIDEOS(state, videos) {
		state.videos = videos
	},
	SET_TAGS(state, tags) {
		state.tags = tags
	},
	SET_USERS(state, users) {
		state.users = users
	}
}

export const actions = {
	async loadAllVideos({ commit }) {
		let { data: videos } = await getData('/course', this.$axios)

		commit('SET_VIDEOS', videos)
	},

	async loadAllTags({ commit }) {
		let { data: tags } = await getData('/course/tags', this.$axios)

		commit('SET_TAGS', tags)
	},

	// FIXME: make this work
	async loadAllUsers({ commit }) {
		let { data: users } = await getData('/user/all', this.$axios)

		commit('SET_USERS', users)
	}
}

const getData = async (url, axios) => {
	let response = await axios.get(url)

	return {
		data: response.data
	}
}
