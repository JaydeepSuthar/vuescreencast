<template>
	<v-app>
		<v-app-bar app color="green">
			<v-btn text to="/">Be A Programmer</v-btn>
			<v-btn text to="/admin">admin</v-btn>
			<v-btn text to="/courses">courses</v-btn>

			<v-btn text>Login / Register</v-btn>
		</v-app-bar>

		<v-main>
			<Nuxt />
		</v-main>
	</v-app>
</template>

<script>
	export default {
		name: 'DefaultLayout',
		middleware: 'load-videos-and-tags',
	}
</script>
