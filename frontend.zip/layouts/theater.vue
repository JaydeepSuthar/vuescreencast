<template>
	<div>
		<div id="theater-body">
			<Nuxt />
		</div>
	</div>
</template>

<script>
	export default {

	}
</script>

<style scoped>

#theater-body {
	background-color: black;
	color: white;
}

</style>
