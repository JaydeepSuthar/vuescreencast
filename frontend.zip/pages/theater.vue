<template>
	<div>
		<h1>I'm in theater</h1>
	</div>
</template>

<script>
	export default {
		layout: 'theater'
	}
</script>

<style scoped>

</style>
