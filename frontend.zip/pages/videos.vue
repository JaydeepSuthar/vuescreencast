<template>
  <div>
	<h3>i am main video page</h3>
	<Nuxt-Child />
  </div>
</template>

<script>
  export default {
    data: () => {
		return {}
    }
  }
</script>

<style lang="scss" scoped>

</style>
