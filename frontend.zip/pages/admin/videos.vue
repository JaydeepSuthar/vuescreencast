<template>
	<v-container>
		<h1>Videos List</h1>
		<v-btn text to="/admin/videos/new">Add Video</v-btn>

		<div class="flex-table">
			<div>Name</div>
			<div>Description</div>
			<div>Actions</div>
		</div>

		<div v-for="video in videos" :key="video.id" class="flex-table">
			<div>{{ video.name }}</div>
			<div>{{ video.description }}</div>
			<div class="actions">
				<NuxtLink
					:to="{ name: 'video-watch', params: { id: video.id } }"
					>Watch</NuxtLink
				>
				<NuxtLink
					:to="{ name: 'admin-video-show', params: { id: video.id } }"
					>Show</NuxtLink
				>
				<NuxtLink
					:to="{ name: 'admin-video-edit', params: { id: video.id } }"
					>Edit</NuxtLink
				>
				<v-btn x-small @click="deleteVideo(video)">Delete</v-btn>
			</div>
		</div>
	</v-container>
</template>

<script>
	import { mapState } from 'vuex'

	export default {
		computed: {
			...mapState({
				videos: (state) => state.videos,
			}),
		},
		filters: {
			abbreviate(text) {
				if (text) {
					text = text.replace('<p>', '')
					return text.slice(0, 50)
				}
			},
		},

		methods: {
			deleteVideo(video) {
				let response = confirm(
					`Are you sure you want to delete this video ${video.title}`
				)
				if (response) {
					this.$store.dispatch('videos/delete', video)
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.flex-table {
		display: grid;
		grid-template-columns: repeat (auto-fill, 33%);
		padding: 10px;
		border-bottom: 1px solid #000;

		&:nth-of-type(2n) {
			background-color: #dedede;
		}

		.actions {
			* {
				padding-right: 15px;
			}
		}
	}
</style>
