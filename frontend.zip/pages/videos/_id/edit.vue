<template>
	<div>
		<h1>Editing {{ $route.params.id }} </h1>
	</div>
</template>

<script>
	export default {
	}
</script>

<style lang="scss" scoped>

</style>
